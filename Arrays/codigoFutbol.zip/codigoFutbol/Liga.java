package codigoFutbol;

import java.util.Arrays;


public class Liga {
	private int numeroEquipos;
	private Equipo[] arrayEquipos;
	
	public Liga (int numeroEquipos){		
		if (numeroEquipos<=0)			
			this.numeroEquipos=5;
		else
			this.setNumeroEquipos(numeroEquipos);
		
		arrayEquipos=new Equipo[this.numeroEquipos];
	}

	public int getNumeroEquipos() {
		return numeroEquipos;
	}

	public void setNumeroEquipos(int numeroEquipos) {
		this.numeroEquipos = numeroEquipos;
	}
	
	@Override
	public String toString() {
		return "Liga [numeroEquipos=" + numeroEquipos + ", arrayEquipos=" + Arrays.toString(arrayEquipos) + "]";
	}

	public boolean altaEquipo(Equipo equipo){
		int codigo;
		boolean altaEquipoOK=false;
		if (equipo==null)
			System.out.println("Error en el equipo a insertar");
		else{
			codigo=equipo.getCodigo();
			if (equipo.getCodigo()>=numeroEquipos)
				System.out.println("No hay sitio en el array para ese c�digo de equipo");
			else
				if (arrayEquipos[codigo-1]!=null && arrayEquipos[codigo-1].equals(equipo)) 
					System.out.println("Error en el alta; ya est� dado de alta ese equipo");
				else 
					if ( arrayEquipos[codigo-1]!=null && arrayEquipos[codigo-1].equals(equipo)==false) 
						System.out.println("Error en el alta; ya est� dado de alta un equipo con ese c�digo y no coincide");
					else {
						arrayEquipos[codigo-1]=equipo;
						altaEquipoOK=true;
					}
		}
		return altaEquipoOK;

	}
	

	public boolean traspaso (Futbolista futbolista, Equipo equipoOrigen, Equipo equipoDestino){
			boolean traspasoOK=false;
			if (equipoDestino.anadirFutbolista(futbolista)==true){
				equipoOrigen.borrarFutbolista(futbolista);
				traspasoOK=true;
			}
			return traspasoOK;	
		
	}

	
}
