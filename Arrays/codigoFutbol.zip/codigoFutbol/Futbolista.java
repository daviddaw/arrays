package codigoFutbol;

public class Futbolista {

	private int codigo;
	private static int contador=0;
	private String nombre;
	private double coste;
	
	public Futbolista(String nombre, double coste){
		contador++;
		codigo=contador;
		this.nombre=nombre;
		this.coste=coste;
	}
	
	public int getCodigo() {
		return codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public double getCoste() {
		return coste;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setCoste(double coste) {
		this.coste = coste;
	}

	@Override
	public String toString() {
		return "Futbolista [codigo=" + codigo + ", nombre=" + nombre
				+ ", coste=" + coste + "]";
	}
	
	
	
	
	
	
	
	
}
