package codigoFutbol;


import java.util.LinkedList;

public class Equipo {
	private int codigo;
	private String nombre;	
	private LinkedList<Futbolista> listaFutbolistas;
	private double presupuesto;
	
	
	public Equipo(int codigo,String nombre, double presupuesto){
		
		if (codigo<0)
			codigo=-codigo;
		this.codigo=codigo;
		
		this.nombre=nombre;
		listaFutbolistas=new LinkedList<Futbolista>();			
		
		if (presupuesto>=100000 && presupuesto<=10000000)
			this.presupuesto=presupuesto;
		else this.presupuesto=100000;		
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	
	public double getPresupuesto() {
		return presupuesto;
	}

	public void setPresupuesto(double presupuesto) {
		if (presupuesto>=100000 && presupuesto<=10000000)
			this.presupuesto=presupuesto;
		else this.presupuesto=100000;		
	}
	
	public LinkedList<Futbolista> getListaFutbolistas() {
		return listaFutbolistas;
	}

	public void setListaFutbolistas(LinkedList<Futbolista> listaFutbolistas) {
		this.listaFutbolistas = listaFutbolistas;
	}

	
	public void incremPresupuesto(double cantidad){
		presupuesto+=cantidad;
	}
	
	@Override
	public String toString() {
		return "Equipo [codigo=" + codigo + ", nombre=" + nombre + ", listaFutbolistas=" + listaFutbolistas
				+ ", presupuesto=" + presupuesto + "]";
	}

	public void disminPresupuesto(double cantidad){
		if (cantidad<=presupuesto)
			presupuesto-=cantidad;
		else
			System.out.println("La cantidad a restar excede del presupuesto; no se actualiza nada");
	}
	

	public boolean anadirFutbolista(Futbolista futbolista){
		
		boolean altaCorrecta; 
		
		if (futbolista.getCoste() > presupuesto){			
			altaCorrecta=false;
		}
		else 
			if (listaFutbolistas.contains(futbolista)){			
				altaCorrecta=false;
			}
			else { 
				listaFutbolistas.add(futbolista);				
				disminPresupuesto(futbolista.getCoste()); 
				altaCorrecta=true;}
		
		return altaCorrecta;

	}
	
	
	
	public boolean borrarFutbolista (Futbolista futbolista){
		boolean bajaOK=listaFutbolistas.remove(futbolista); //intentamos borrar el futbolista
		if (bajaOK==true) 			
			incremPresupuesto(futbolista.getCoste());	
		else 
			System.out.println("No se puede borrar al futbolista");
		
		return bajaOK;
		
	}
	
	
	
	

}
